<div class="field submit-field">
    <button type="submit"><?php echo $buttontext; ?></button>
</div>