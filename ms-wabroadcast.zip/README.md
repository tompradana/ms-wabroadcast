# MS WhatsApp Broadcast
MS-WABroadcast Plugin to collect subscriber and send broadcasr whatsapp message through admin WordPress using Fonnte WhatsApp API

## Change Log

### 1.0.0
- initial release